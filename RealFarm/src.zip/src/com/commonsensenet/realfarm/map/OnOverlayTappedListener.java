package com.commonsensenet.realfarm.map;

public interface OnOverlayTappedListener {

	public abstract void onOverlayTapped(Overlay overlay);
}
