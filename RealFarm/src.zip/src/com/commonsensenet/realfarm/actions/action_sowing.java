package com.commonsensenet.realfarm.actions;

import com.commonsensenet.realfarm.R;
import com.commonsensenet.realfarm.Settings;
import com.commonsensenet.realfarm.WF_details;
import com.commonsensenet.realfarm.admincall;
import com.commonsensenet.realfarm.control.NumberPicker;
import com.commonsensenet.realfarm.dataaccess.RealFarmProvider;
import com.commonsensenet.realfarm.homescreen.Homescreen;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class action_sowing extends Activity {
	
	
	 public void onBackPressed() {
			
			
			Intent adminintent = new Intent(action_sowing.this,Homescreen.class);
			        
			      startActivity(adminintent);                        
			      action_sowing.this.finish();
}
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	System.out.println("Plant details entered");
   
    	        super.onCreate(savedInstanceState);
    	        setContentView(R.layout.sowing_dialog);
    	    	System.out.println("plant done");
    
    final Button item1;
    final Button item2;
    final Button item3;
    item1 = (Button) findViewById(R.id.home_btn_var_sow);
 //   item2 = (Button) findViewById(R.id.home_btn_qty_sow);
    item3 = (Button) findViewById(R.id.home_btn_day_sow);

	item1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Log.d("in variety sowing dialog", "in dialog");
				Dialog dlg = new Dialog(v.getContext());
		    	dlg.setContentView(R.layout.variety_sowing_dialog);
		    	dlg.setCancelable(true);
		        dlg.setTitle("Choose the Variety of seed sowed");
		    	Log.d("in variety sowing dialog", "in dialog");
		    	dlg.show();

			
			}
		});
    
	
	item3.setOnClickListener(new View.OnClickListener() {
		public void onClick(View v) {
			Log.d("in day sowing dialog", "in dialog");
			Dialog dlg = new Dialog(v.getContext());
	    	dlg.setContentView(R.layout.days_dialog);
	    	dlg.setCancelable(true);
	        dlg.setTitle("Choose the day");
	    	Log.d("in day sowing dialog", "in dialog");
	    	dlg.show();

		
		}
	});
   
    }
    

    
    
    
    
    
    
    
    
    
    
    
}