package com.commonsensenet.realfarm.actions;

import com.commonsensenet.realfarm.R;
import com.commonsensenet.realfarm.Settings;
import com.commonsensenet.realfarm.WF_details;
import com.commonsensenet.realfarm.admincall;
import com.commonsensenet.realfarm.control.NumberPicker;
import com.commonsensenet.realfarm.dataaccess.RealFarmProvider;
import com.commonsensenet.realfarm.homescreen.Homescreen;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class action_selling extends Activity {
	
	
	 public void onBackPressed() {
			
			
			Intent adminintent = new Intent(action_selling.this,Homescreen.class);
			        
			      startActivity(adminintent);                        
			      action_selling.this.finish();
}
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	System.out.println("Plant details entered");
   
    	        super.onCreate(savedInstanceState);
    	        setContentView(R.layout.selling_dialog);
    	    	System.out.println("plant done");
    
    final Button item1;
    item1 = (Button) findViewById(R.id.home_btn_sell_1);
    

	item1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Log.d("in selling dialog", "in dialog");
				Dialog dlg = new Dialog(v.getContext());
		    	dlg.setContentView(R.layout.quality_selling_dialog);
		    	dlg.setCancelable(true);
		    dlg.setTitle("Choose the Quality of seeds");
		    	Log.d("in selling dialog", "in dialog");
		    	dlg.show();

			
			}
		});
    
   
   
    }
    

    
    
    
    
    
    
    
    
    
    
    
}